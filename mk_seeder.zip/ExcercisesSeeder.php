<?php
    namespace Database\Seeders;

    use Illuminate\Database\Seeder;
    use Illuminate\Support\Facades\DB;


    class ExcercisesSeeder extends Seeder
    {
        public function run()
        {
            DB::table('excercises')->insert(['id' => '12' ,'name' => 'excercise1' ,'description' => 'first excercise' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-19 21:58:53' ,'updated_at' => '2022-07-19 22:01:46' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '13' ,'name' => 'excercise2' ,'description' => 'second excercise' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-19 22:02:39' ,'updated_at' => '2022-07-19 22:02:39' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '14' ,'name' => 'excercis3' ,'description' => 'ex3' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-20 16:31:38' ,'updated_at' => '2022-07-20 16:31:38' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '15' ,'name' => 'Cardio Exercise' ,'description' => 'Cardio is defined as any type of exercise that gets your heart rate up and keeps it up for a prolonged period of time. Your respiratory system will start working harder as you begin to breathe faster and more deeply.' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-22 19:03:43' ,'updated_at' => '2022-07-22 19:03:43' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '16' ,'name' => 'Name' ,'description' => 'Decr' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-22 19:11:19' ,'updated_at' => '2022-07-22 19:11:19' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '17' ,'name' => 'Add' ,'description' => 'New' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-22 19:17:52' ,'updated_at' => '2022-07-22 19:49:47' ,'deleted_at' => '2022-07-22 19:49:47' ,]);
        DB::table('excercises')->insert(['id' => '18' ,'name' => 'VV' ,'description' => 'VV' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-22 19:19:35' ,'updated_at' => '2022-07-22 19:20:36' ,'deleted_at' => '2022-07-22 19:20:36' ,]);
        DB::table('excercises')->insert(['id' => '19' ,'name' => 'padmasana' ,'description' => 'padmasana description' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-28 20:33:44' ,'updated_at' => '2022-07-28 20:33:44' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '20' ,'name' => 'ex1' ,'description' => 'gfdgf' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-29 23:53:55' ,'updated_at' => '2022-07-29 23:53:55' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '21' ,'name' => 'New Exercise' ,'description' => 'New description' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-07-31 16:57:49' ,'updated_at' => '2022-07-31 16:57:49' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '22' ,'name' => 'padmasana1' ,'description' => 'desc1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-30 21:57:21' ,'updated_at' => '2022-08-30 22:13:24' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '23' ,'name' => 'Free Hand' ,'description' => 'Free Hand Exercises' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-31 20:42:37' ,'updated_at' => '2022-08-31 20:51:51' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '24' ,'name' => 'exercise_breathing' ,'description' => 'breating' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-09-01 00:30:29' ,'updated_at' => '2022-09-01 00:32:13' ,'deleted_at' => '2022-09-01 00:32:13' ,]);
        DB::table('excercises')->insert(['id' => '26' ,'name' => 'ex_br' ,'description' => 'desc' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-09-01 00:34:41' ,'updated_at' => '2022-09-01 00:35:51' ,'deleted_at' => '2022-09-01 00:35:51' ,]);
        DB::table('excercises')->insert(['id' => '31' ,'name' => 'exercise_breathing' ,'description' => 'desc' ,'created_by' => '137' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-09-01 16:39:29' ,'updated_at' => '2022-09-01 16:39:56' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '32' ,'name' => 'teamexcercise' ,'description' => 'very good' ,'created_by' => '137' ,'approved_by' => '137' ,'status' => '1' ,'created_at' => '2022-09-01 18:27:40' ,'updated_at' => '2022-09-01 18:29:03' ,'deleted_at' => '2022-09-01 18:29:03' ,]);
        DB::table('excercises')->insert(['id' => '33' ,'name' => 'myexercise1' ,'description' => '454545456' ,'created_by' => '137' ,'approved_by' => null ,'status' => '2' ,'created_at' => '2022-09-05 20:34:25' ,'updated_at' => '2022-09-05 20:34:25' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '34' ,'name' => 'jumping jack' ,'description' => 'cardio' ,'created_by' => '26' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-09-08 19:25:50' ,'updated_at' => '2022-09-08 19:26:08' ,'deleted_at' => null ,]);
        DB::table('excercises')->insert(['id' => '35' ,'name' => 'Free Hand' ,'description' => 'Free Hand' ,'created_by' => '159' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-09-10 00:39:02' ,'updated_at' => '2022-09-10 00:44:51' ,'deleted_at' => null ,]);
    }
    }
    
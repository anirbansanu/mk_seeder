<?php
    namespace Database\Seeders;

    use Illuminate\Database\Seeder;
    use Illuminate\Support\Facades\DB;


    class VaccinesSeeder extends Seeder
    {
        public function run()
        {
            DB::table('vaccines')->insert(['id' => '1' ,'name' => 'vaccine1' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'mandatory' ,'patient_type' => '2' ,'when_to_give' => '16-24 months' ,'dose' => '0.5 ml' ,'route' => 'Sub-cutaneous' ,'site' => 'Left Upper Arm' ,'status' => '1' ,'created_at' => '2022-06-23 16:51:09' ,'updated_at' => '2022-06-28 15:45:30' ,'deleted_at' => null ,]);
        DB::table('vaccines')->insert(['id' => '2' ,'name' => 'TT-1' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'mandatory' ,'patient_type' => '1' ,'when_to_give' => 'Early in pregnancy' ,'dose' => '0.5 ml' ,'route' => 'Intra-muscular' ,'site' => 'Upper Arm' ,'status' => '1' ,'created_at' => '2022-06-23 16:56:54' ,'updated_at' => '2022-06-28 16:29:36' ,'deleted_at' => null ,]);
        DB::table('vaccines')->insert(['id' => '3' ,'name' => 'TT-2' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'mandatory' ,'patient_type' => '1' ,'when_to_give' => '4 weeks after TT-1*' ,'dose' => '0.5 ml' ,'route' => 'Intra-muscular' ,'site' => 'Upper Arm' ,'status' => '1' ,'created_at' => '2022-06-23 16:58:27' ,'updated_at' => '2022-06-28 16:29:57' ,'deleted_at' => null ,]);
        DB::table('vaccines')->insert(['id' => '4' ,'name' => 'TT- Booster' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'optional' ,'patient_type' => '1' ,'when_to_give' => 'If received 2 TT doses in a pregnancy  within the last 3 yrs*' ,'dose' => '0.5 ml' ,'route' => 'Intra-muscular' ,'site' => 'Upper Arm' ,'status' => '1' ,'created_at' => '2022-06-23 23:54:10' ,'updated_at' => '2022-06-28 16:30:32' ,'deleted_at' => null ,]);
        DB::table('vaccines')->insert(['id' => '5' ,'name' => 'Covishield' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'mandatory' ,'patient_type' => '4' ,'when_to_give' => 'Anytime' ,'dose' => 'Booster Dose' ,'route' => 'Upper Arm' ,'site' => 'No Site' ,'status' => '1' ,'created_at' => '2022-06-24 15:38:23' ,'updated_at' => '2022-06-28 15:47:12' ,'deleted_at' => null ,]);
        DB::table('vaccines')->insert(['id' => '6' ,'name' => 'vaccine2' ,'type_of_vaccine' => 'injection' ,'mandatory_optional' => 'optional' ,'patient_type' => '1' ,'when_to_give' => '78978' ,'dose' => '.5ml' ,'route' => 'arm' ,'site' => 'helo' ,'status' => '1' ,'created_at' => '2022-06-28 15:46:49' ,'updated_at' => '2022-06-28 15:48:42' ,'deleted_at' => '2022-06-28 15:48:42' ,]);
    }
    }
    
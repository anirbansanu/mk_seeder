<?php
    namespace Database\Seeders;

    use Illuminate\Database\Seeder;
    use Illuminate\Support\Facades\DB;


    class BloodtestUnitsSeeder extends Seeder
    {
        public function run()
        {
            DB::table('bloodtest_units')->insert(['id' => '21' ,'unit' => 'u2' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-12 10:26:29' ,'updated_at' => '2022-08-17 23:59:40' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '22' ,'unit' => 'u1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-12 11:38:00' ,'updated_at' => '2022-08-12 11:38:00' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '30' ,'unit' => 'cm' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-12 15:10:31' ,'updated_at' => '2022-08-12 15:10:31' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '31' ,'unit' => 'mm1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-12 15:12:27' ,'updated_at' => '2022-08-12 18:38:53' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '32' ,'unit' => 'mm' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-16 15:29:26' ,'updated_at' => '2022-08-16 15:29:26' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '35' ,'unit' => 'Feet 1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-16 21:07:03' ,'updated_at' => '2022-08-16 21:07:47' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '36' ,'unit' => 'Tropical Unit' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-16 21:45:17' ,'updated_at' => '2022-08-16 21:45:17' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '37' ,'unit' => 'CMS' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-16 21:52:08' ,'updated_at' => '2022-08-16 21:52:08' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '38' ,'unit' => 'mg1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-17 23:59:57' ,'updated_at' => '2022-08-18 00:01:15' ,'deleted_at' => '2022-08-18 00:01:15' ,]);
        DB::table('bloodtest_units')->insert(['id' => '39' ,'unit' => 'mg11' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-18 00:01:21' ,'updated_at' => '2022-08-18 00:02:26' ,'deleted_at' => '2022-08-18 00:02:26' ,]);
        DB::table('bloodtest_units')->insert(['id' => '40' ,'unit' => 'mg' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-19 17:52:46' ,'updated_at' => '2022-08-19 17:52:46' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '41' ,'unit' => 'Parameter' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:30:24' ,'updated_at' => '2022-08-24 18:30:24' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '42' ,'unit' => 'Mechanical' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:30:47' ,'updated_at' => '2022-08-24 19:16:27' ,'deleted_at' => '2022-08-24 19:16:27' ,]);
        DB::table('bloodtest_units')->insert(['id' => '43' ,'unit' => 'Mark 1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:35:00' ,'updated_at' => '2022-08-24 18:36:02' ,'deleted_at' => '2022-08-24 18:36:02' ,]);
        DB::table('bloodtest_units')->insert(['id' => '44' ,'unit' => 'Support' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:50:55' ,'updated_at' => '2022-08-24 18:57:11' ,'deleted_at' => '2022-08-24 18:57:11' ,]);
        DB::table('bloodtest_units')->insert(['id' => '45' ,'unit' => 'New1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:56:55' ,'updated_at' => '2022-08-29 18:39:46' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '46' ,'unit' => 'Support' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 18:57:18' ,'updated_at' => '2022-08-24 18:57:18' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '47' ,'unit' => 'Safari' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 19:27:30' ,'updated_at' => '2022-08-24 20:58:17' ,'deleted_at' => '2022-08-24 20:58:17' ,]);
        DB::table('bloodtest_units')->insert(['id' => '48' ,'unit' => 'Macro' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 19:27:39' ,'updated_at' => '2022-08-24 19:27:39' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '49' ,'unit' => 'Latest Unit' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 20:15:28' ,'updated_at' => '2022-08-24 20:15:28' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '50' ,'unit' => 'Tsunami Unit' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 20:17:43' ,'updated_at' => '2022-08-24 20:17:43' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '51' ,'unit' => 'Space unit' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 21:03:07' ,'updated_at' => '2022-08-24 21:03:07' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '52' ,'unit' => 'Hyundai Unit' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-24 21:03:42' ,'updated_at' => '2022-08-24 21:03:42' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '53' ,'unit' => 'Hemo 1' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-26 16:52:00' ,'updated_at' => '2022-08-26 16:52:00' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '54' ,'unit' => 'Hemo 2' ,'created_by' => null ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-26 16:52:05' ,'updated_at' => '2022-08-26 16:52:05' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '57' ,'unit' => 'test29' ,'created_by' => '137' ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-08-29 19:31:10' ,'updated_at' => '2022-08-29 19:42:50' ,'deleted_at' => '2022-08-29 19:42:50' ,]);
        DB::table('bloodtest_units')->insert(['id' => '58' ,'unit' => 'test30' ,'created_by' => '137' ,'approved_by' => '137' ,'status' => '1' ,'created_at' => '2022-08-29 19:37:04' ,'updated_at' => '2022-08-29 19:42:48' ,'deleted_at' => '2022-08-29 19:42:48' ,]);
        DB::table('bloodtest_units')->insert(['id' => '59' ,'unit' => 'test29' ,'created_by' => '137' ,'approved_by' => '137' ,'status' => '1' ,'created_at' => '2022-08-29 19:42:59' ,'updated_at' => '2022-08-29 19:43:19' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '60' ,'unit' => 'testying12' ,'created_by' => '137' ,'approved_by' => '137' ,'status' => '2' ,'created_at' => '2022-08-29 20:53:52' ,'updated_at' => '2022-08-29 20:53:52' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '61' ,'unit' => 't1u1' ,'created_by' => '26' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-08-30 15:53:17' ,'updated_at' => '2022-08-30 15:53:17' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '62' ,'unit' => 'Supreme Unit' ,'created_by' => '26' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-08-31 18:52:00' ,'updated_at' => '2022-08-31 18:53:40' ,'deleted_at' => '2022-08-31 18:53:40' ,]);
        DB::table('bloodtest_units')->insert(['id' => '63' ,'unit' => 'Supreme Unit' ,'created_by' => '159' ,'approved_by' => '159' ,'status' => '1' ,'created_at' => '2022-08-31 18:54:00' ,'updated_at' => '2022-08-31 18:59:49' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '64' ,'unit' => 'Supremo Unit' ,'created_by' => '26' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-08-31 19:32:38' ,'updated_at' => '2022-08-31 19:32:38' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '65' ,'unit' => 'bloodtestunit1' ,'created_by' => '26' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-08-31 21:17:50' ,'updated_at' => '2022-08-31 21:17:50' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '69' ,'unit' => 'Scooby Unit' ,'created_by' => '159' ,'approved_by' => '26' ,'status' => '1' ,'created_at' => '2022-09-10 00:13:38' ,'updated_at' => '2022-09-10 00:14:27' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '70' ,'unit' => 'New' ,'created_by' => '26' ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-09-10 00:20:18' ,'updated_at' => '2022-09-10 00:20:18' ,'deleted_at' => null ,]);
        DB::table('bloodtest_units')->insert(['id' => '71' ,'unit' => 'EU' ,'created_by' => '26' ,'approved_by' => null ,'status' => '1' ,'created_at' => '2022-09-10 00:22:45' ,'updated_at' => '2022-09-10 00:22:45' ,'deleted_at' => null ,]);
    }
    }
    